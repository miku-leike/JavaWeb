package com.gzs.homeworkfilter;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

@WebFilter(filterName = "LoginFilter",urlPatterns = "/*")
public class LoginFilter implements Filter {
    private String encoding = "UTF-8";
    //创建排除列表，包含不需要登录就能访问的路径
    private static final List<String> STATIC_EXTENSIONS = Arrays.asList(
            "/login", "/register", "/public", "/index.jsp"
    );

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        String encodingParam = filterConfig.getInitParameter("encoding");
        //检查encoding参数，没有默认UTF-8
        if (encodingParam != null && !encodingParam.isEmpty()) {
            encoding = encodingParam;
        }
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) throws IOException, ServletException {
        System.out.println("MyFilter is 创建完成");
        //验证
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        String requestURI = httpRequest.getRequestURI().toLowerCase();

        boolean isStaticResource = STATIC_EXTENSIONS.stream().anyMatch(extension -> requestURI.endsWith(extension));
        //检查当前请求是否在对排除列表中的路径进行请求
        if (isStaticResource) {
            filterChain.doFilter(request, response);
            return;
        }
        else {
            HttpSession session = httpRequest.getSession();
            if(session != null){
                //得到网页中的用户名与密码
                String userName = (String) session.getAttribute("User");
                String password = (String) session.getAttribute("Password");
                System.out.println("userName:" + userName + " " +"password:" + password);
                //设置默认用户名与密码
                String userName_default = "gan";
                String password_default = "123";

                //检查得到的用户名与密码是否通过
                if(Objects.equals(userName_default,userName) && Objects.equals(password_default,password)) {
                    System.out.println("登陆成功！");
                    filterChain.doFilter(request, response);
                } else{
                    System.out.println("重定向到登录页面");
                    httpResponse.sendRedirect(httpRequest.getContextPath() + "/index.jsp");
                }
            }
            else {
                System.out.println("session为空且不在排除页面，重定向到登录页面");
                httpResponse.sendRedirect(httpRequest.getContextPath() + "/index.jsp");
            }
        }

    }


    @Override
    public void destroy() {
        Filter.super.destroy();
    }
}
