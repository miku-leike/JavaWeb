package com.gzs.homeworkfilter;

import java.io.*;
import java.util.Objects;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet(name = "helloServlet", urlPatterns = "/login")
public class LoginServlet extends HttpServlet {
    private String message;

    public void init() {
        message = "Hello World!";
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        HttpSession session = request.getSession();
        //得到网页中提交的用户名与密码存储到session中
        String userName = request.getParameter("userName");
        String password = request.getParameter("password");
        System.out.println("userName: " + userName + "  password1: " + password);
        session.setMaxInactiveInterval(60);
        session.setAttribute("User", userName);
        session.setAttribute("Password",password);
        System.out.println("LoginServlet 已执行！");
        String userName_default = "gan";
        String password_default = "123";

        //检查得到的用户名与密码是否通过
        if(Objects.equals(userName_default,userName) && Objects.equals(password_default,password)) {
            System.out.println("登陆成功！");
            response.sendRedirect(request.getContextPath() + "/loginSuccess.html");
        } else{
            System.out.println("重定向到登录页面");
            response.sendRedirect(request.getContextPath() + "/index.jsp");
        }


        //清除会话
        //session.invalidate();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doPost(req, resp);
    }
}