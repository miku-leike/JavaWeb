# 功能介绍

## 概览
此文档涵盖了两个Java类：`RequestListener` 和 `HelloServlet`。这些类旨在监听j记录HelloServlet响应时的信息，并打印在控制台中

## RequestListener类

### 目的
`RequestListener` 是一个实现了 `ServletRequestListener` 接口的Java类，用于监听和记录HTTP请求的生命周期。

### 功能
- 在请求初始化时记录请求开始时间。
- 在请求销毁时计算处理总时间并记录请求的详细信息。

### 方法 
### requestInitialized(ServletRequestEvent sre)
当请求被初始化时调用此方法。它记录请求的开始时间，并将其作为属性存储在请求对象中。
### requestDestroyed(ServletRequestEvent sre)
当请求被销毁时调用此方法。它计算请求处理的总时间，并记录请求的详细信息，包括客户端 IP、请求方法、请求 URI、查询字符串和用户代理。

## HelloServlet类

### 目的
HelloServlet 是一个继承自 HttpServlet 的Java类，用于处理HTTP GET请求。它通过 @WebServlet 注解指定其URL映射。

### 功能
- 在Servlet初始化时设置问候消息。
- 在处理GET请求时返回包含问候消息的HTML页面。
- 在响应中输出额外的测试信息。
### 方法
### init()
在Servlet初始化时调用此方法。它设置了Servlet的问候消息。
### doGet(HttpServletRequest request, HttpServletResponse response)
当Servlet接收到GET请求时调用此方法。它设置响应内容类型为text/html并生成包含问候消息的HTML页面。

## 注意事项
- 确保 RequestListener 类在 web.xml 中被正确配置，或者使用 @WebListener 注解自动注册。
- 类使用了jakarta.servlet包，确保项目依赖中包含必要的库。