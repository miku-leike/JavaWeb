#javaweb
#40道学生选课题
#1
select * from student;
#2
select * from course;
#3
select name,student_id,my_class from student;
#4
select name,title from teacher;
#5
select course_id,avg(score)平均分
from score
group by course_id;
#6
select name,avg(score)平均分
from score s1
join student s2 on s1.student_id = s2.student_id
group by s1.student_id;
#7
select name,course_id
from student s1
join score s2 on s1.student_id = s2.student_id
where s2.score>85;
#8
select course_id,count(student_id)人数
from score
group by course_id;
#9
select name,score
from score s1
join student s2 on s1.student_id = s2.student_id
join course c on c.course_id = s1.course_id
where course_name = '大学物理';
#10
select name from student
where student_id not in(select s.student_id from student
                        join score s on student.student_id = s.student_id
                        join course c on c.course_id = s.course_id
                        where course_name = '大学物理');
#11
select *
from score s1
left join score s2 on s1.student_id = s2.student_id
where s1.course_id = 'C001' and s2.course_id !='C004';
#12
select name,sum(score)
from score
join student s on score.student_id = s.student_id
group by s.student_id
order by sum(score) desc
limit 3;
#13
select gender,count(student_id)人数
from student
group by gender;
#15
select name,birth_date
from student
order by birth_date
limit 1;
#16
select name,birth_date
from teacher
order by birth_date desc
limit 1;
#17
select *
from student
join score s on student.student_id = s.student_id
join course c on c.course_id = s.course_id
join teacher t on t.teacher_id = c.teacher_id
where t.name = '张教授';
#18
select distinct student.*
from student
join score s on student.student_id = s.student_id
where s.course_id in(select course_id from score
                    where student_id = '2021001') and s.student_id!='2021001';
#19
select course_id,avg(score.score) avg
from score
group by course_id
order by avg desc ;
#20
select course_id,score.score from score
where student_id = '2021001';
#21
select name,course_name,score
from score
join student s on s.student_id = score.student_id
join course c on c.course_id = score.course_id;
#22
select name,avg(score)
from score
join course c on c.course_id = score.course_id
join teacher t on t.teacher_id = c.teacher_id
group by t.teacher_id;
#23
select name,course_name
from student
join score s on student.student_id = s.student_id
join course c on c.course_id = s.course_id
where score between 80 and 90;
#24
select student.my_class,avg(s.score)平均分
from student
join score s on student.student_id = s.student_id
group by my_class;
#25
select name
from student
where student_id not in(
    select student_id
    from score
    join course c on c.course_id = score.course_id
    join teacher t on t.teacher_id = c.teacher_id
    where t.name = '王讲师'
    );
#26
with less as (
    select student.student_id,avg(score) avg
    from student
    join score s on student.student_id = s.student_id
    group by student.student_id
    having avg<85
)
select s.student_id,s.name,avg
from student s
join less on less.student_id = s.student_id
group by s.student_id
having count(avg) ;
#27
select name,sum(score.score) s
from score
join student s2 on s2.student_id = score.student_id
group by s2.student_id
order by s desc ;
#28
select course.course_name,avg(score)
from course
join score s on course.course_id = s.course_id
group by s.course_id
having avg(score)>85;
#29
select student.name,avg(s.score) s1
from student
join score s on student.student_id = s.student_id
group by s.student_id
order by s1 desc ;
#30
select distinct name
from student
join score s on student.student_id = s.student_id
join course c on c.course_id = s.course_id
where course_name = '高等数学' or course_name = '大学物理';
#31
with av as (
    select student_id,avg(score.score) avg
    from score
    group by student_id
)
select student.name,course_id,s.score,avg
from student
left join score s on student.student_id = s.student_id
left join av on av.student_id = s.student_id;
#32
select name,score
from student
join score s on student.student_id = s.student_id
where score = (
    select MAX(score)
    from student join
    score s2 on student.student_id = s2.student_id)
union
select name,score
from student
join score s on student.student_id = s.student_id
where score = (
    select min(score)
    from student join
    score s2 on student.student_id = s2.student_id);
#33
select my_class,max(score)
from student
join score s2 on student.student_id = s2.student_id
group by my_class
union
select my_class,min(score)
from student join score s2 on student.student_id = s2.student_id
group by my_class
order by my_class;
#34
select c.course_name,
round(sum(case when score>=90 then 1 else 0 end ) / count(*)*100,2) as rate
from score
join course c on c.course_id = score.course_id
group by course_name;
#35
select name,score,avg,score-avg
from score
join student s on s.student_id = score.student_id
join (select student_id,avg(score.score) avg
      from score
      group by student_id) as s2
on s2.student_id = s.student_id;
#36
select s1.name
from student s1
join score s2 on s1.student_id = s2.student_id
group by s1.name
having min(s2.score) < 80;
#37
select s.name
from student s
join score c on s.student_id = c.student_id
group by s.name
having max(c.score) > 85 AND min(c.score) > 85;
#38
select s.student_id , name, avg(score) average_score
from student s
join score c on s.student_id = c.student_id
group by s.student_id, s.name
having avg(c.score) >= 90;
#39
select st.name,s1.av1,s2.av2
from student st
join (select score.student_id,avg(score.score) av1
      from score
      group by score.student_id) as s1 on st.student_id = s1.student_id
join (select st2.my_class,avg(s.score) av2
      from student st2
      join score s on st2.student_id = s.student_id
      group by st2.my_class) as s2 on s2.my_class = st.my_class
where s1.av1 > s2.av2;

#40
with s as (
    select s1.student_id,s1.score 'C001',s2.score 'C002'
    from score s1
    join score s2 on s1.student_id = s2.student_id
    where s1.course_id = 'C001' and s2.course_id = 'C002'
)
select *
from student st
join s on st.student_id = s.student_id
where s.C001>s.C002;