#javaweb
#25道员工信息题
#1
select first_name,email,job_title as 工作岗位
from employees;
#2
select dept_name,location
from departments;
#3
select first_name,salary
from employees
where salary > 70000;
#4
select *
from employees,departments
where employees.dept_id=departments.dept_id and dept_name = 'IT';
#5
select *
from employees
where year(hire_date) >= 2020;
#6
select departments.dept_name,avg(employees.salary) as 平均工资
from employees
join departments on employees.dept_id = departments.dept_id
group by employees.dept_id
order by 平均工资;
#7
select *
from employees e
order by e.salary desc
limit 0,3;
#8
select employees.dept_id, count(*)
from employees
join departments on employees.dept_id = departments.dept_id
group by dept_id;
#9
select *
from employees
where dept_id is not null;
#10
select first_name,count(project_id)
from employees
join employee_projects on employees.emp_id = employee_projects.emp_id
group by employees.emp_id;
#11
select sum(salary) as 工资总和
from employees;
#12
select *
from employees
where last_name = 'Smith';
#13
select *
from projects
where end_date between curdate() and adddate(curdate(),interval 6 month);
#14
select e.emp_id,count(ep.project_id) 项目数
from employees e
join employee_projects ep on e.emp_id = ep.emp_id
group by e.emp_id
having 项目数>=2;
#15
select distinct *
from employees e
left join employee_projects ep on e.emp_id=ep.emp_id
where ep.project_id is null;
#16
select p.project_id, count(emp_id) 员工数量
from projects p
join employee_projects ep on p.project_id=ep.project_id
group by ep.project_id;
#17
with salary_top2 as (
    select distinct salary
    from employees e
    order by e.salary desc
    limit 1,1
)
select *
from employees e
where e.salary in (select * from salary_top2);
#18
with max_salary as(
    select e.emp_id,max(e.salary) as max_salary
    from employees e
    group by e.emp_id
)
select e.*
from employees e
join max_salary ms on e.dept_id=ms.emp_id
where e.salary=ms.max_salary;
#19
select sum(salary),dept_name
from employees e
join departments d on d.dept_id=e.dept_id
group by d.dept_id
order by sum(salary) desc;
#20
select concat(first_name,last_name) 姓名,dept_name,salary
from employees e
join departments d on d.dept_id=e.dept_id;
#21
select concat(ea.first_name,ea.last_name)姓名,ea.emp_id,
       concat(eb.first_name,eb.last_name)上级,eb.emp_id
from employees ea
left join employees eb on ea.emp_id=eb.emp_id+1;
#22
select distinct dept_name
from employees e
join employee_management.departments d on d.dept_id = e.dept_id;
#23
with high as (
    select d.dept_id,AVG(salary) as avg from employees
    join employee_management.departments d on d.dept_id = employees.dept_id
    group by d.dept_id
    order by avg desc
    limit 1
)
select dept_name,avg
from departments d
join high h on h.dept_id = d.dept_id;
#24
with avg as (
    select d.dept_id,avg(salary) as sa_avg from employees e
    join employee_management.departments d on d.dept_id = e.dept_id
    group by d.dept_id
)
select concat(first_name,last_name)姓名
from employees e
join avg on avg.dept_id = e.dept_id
where e.salary>sa_avg;
#25
select *
from employees
where concat(first_name,last_name) like '%son%';