# 功能介绍

## LoginFilter类
### 目的
`LoginFilter` 是一个实现了 `Filter` 接口的 Java 类，用于在 Servlet 应用中进行登录验证。该类通过 `@WebFilter` 注解被标记为一个过滤器，并指定了其过滤的 URL 模式为 `/*`，表示对所有路径进行过滤。

### 功能
- 初始化过滤器时，设置请求编码。
- 在过滤操作中，验证用户是否已经登录，若未登录则重定向至登录页面。

### 方法
### init(FilterConfig filterConfig)
在过滤器初始化时调用此方法。它从配置中读取编码参数，并设置为过滤器的编码。
### doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain)
在请求到达目标资源之前调用此方法。它检查请求是否为静态资源或是否已经登录，若未登录则重定向至登录页面。
### destroy()
在过滤器销毁时调用此方法。当前实现为空，可以在此方法中添加清理资源的代码。

## LoginServlet类
### 目的
`LoginServlet`是一个继承自`HttpServlet`的 Java 类，用于处理用户登录请求。该类通过 `@WebServlet` 注解被标记为一个 Servlet，并且指定了其处理的 URL 模式为 `/login`。

### 功能
- 在 Servlet 初始化时设置问候消息。
- 在处理 GET 请求时，获取用户提交的用户名和密码，并验证这些凭证。
- 如果凭证有效，重定向用户到登录成功页面；否则，重定向回登录页面。

### 方法
### doGet(HttpServletRequest request, HttpServletResponse response)
当 Servlet 接收到 GET 请求时调用此方法。它获取用户提交的用户名和密码，验证这些凭证，然后根据验证结果重定向用户。
### doPost(HttpServletRequest req, HttpServletResponse resp)
处理 POST 请求的方法。当前实现中，此方法直接调用了父类的 doPost 方法。

## 注意事项
- 确保 LoginFilter 和 LoginServlet 类在 web.xml 中正确配置，或者使用注解进行自动注册。
- 这两个类使用了 jakarta.servlet 包，确保项目依赖中包含必要的库。
- 过滤器和 Servlet 的逻辑可以根据实际需要进行修改和扩展。