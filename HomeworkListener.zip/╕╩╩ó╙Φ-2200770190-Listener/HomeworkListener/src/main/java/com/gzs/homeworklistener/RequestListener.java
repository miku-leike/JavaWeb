package com.gzs.homeworklistener;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebListener;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSessionListener;

import java.time.Clock;
import java.time.Duration;
import java.time.LocalDateTime;

//标记监听器
@WebListener
public class RequestListener implements ServletRequestListener {
    @Override
    public void requestInitialized(ServletRequestEvent sre) {
        HttpServletRequest request = (HttpServletRequest) sre.getServletRequest();

        // 记录请求开始时间
        LocalDateTime startTime = LocalDateTime.now(Clock.systemDefaultZone());
        request.setAttribute("startTime", startTime);


    }

    @Override
    public void requestDestroyed(ServletRequestEvent sre) {
        HttpServletRequest request = (HttpServletRequest) sre.getServletRequest();
        //得到响应开始时间
        LocalDateTime startTime = (LocalDateTime) request.getAttribute("startTime");
        //得到响应结束时间
        LocalDateTime endTime = LocalDateTime.now(Clock.systemDefaultZone());
        //使用Duration.between方法计算时间差
        Duration elapsedTime = Duration.between(startTime, endTime);
        // 记录请求信息
        String clientIp = request.getRemoteAddr();
        String method = request.getMethod();
        String uri = request.getRequestURI();
        String queryString = request.getQueryString() != null ? "?" + request.getQueryString() : "";
        String userAgent = request.getHeader("User-Agent");
        //打印日志信息
        System.out.println(" clientIp:" + clientIp + " elapsed time:" + elapsedTime + " method:" + method + " uri:" + uri + " query:" + queryString + " userAgent:" + userAgent);
    }
}
