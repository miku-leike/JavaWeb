package com.gzs;

import java.sql.*;

public class ViewSecondLastTeacher {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/jdbc_demo?serverTimezone=GMT&characterEncoding=UTF-8";
        String user = "root";
        String password = "123";

        String sql = "select * from teacher where id = ?";
        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement ps = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        ) {
            ps.setString(1, "name20"); // 假设我们要查找名字为"name20"的教师
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.last()) { // 移动到最后一行
                    int rowCount = rs.getRow(); // 获取总行数
                    rs.absolute(rowCount - 2); // 移动到倒数第二行
                    System.out.println("ID: " + rs.getInt("id") + ", Name: " + rs.getString("name"));
                } else {
                    System.out.println("No rows found.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
}
