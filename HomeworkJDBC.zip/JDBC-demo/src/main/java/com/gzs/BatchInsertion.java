package com.gzs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class BatchInsertion {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/jdbc_demo?serverTimezone=GMT&characterEncoding=UTF-8";
        String user = "root";
        String password = "123";
        String sql = "insert into teacher(id,name,course,birthday) values(?,?,?,?)";
        try (Connection conn = DriverManager.getConnection(url, user, password);) {
            conn.setAutoCommit(false);
            try (PreparedStatement ps = conn.prepareStatement(sql);) {
                // 设置参数
                LocalDate startDate = LocalDate.of(2022, 2, 28); // 起始日期
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                for (int i = 2; i <= 500; i++) {
                    ps.setInt(1, i);
                    ps.setString(2, "name" + i);
                    ps.setString(3, i+"课程");
                    LocalDate birthday = startDate.plusDays(i - 2); // 计算每个人的生日
                    ps.setString(4, birthday.format(formatter));
                    // 添加到批处理
                    ps.addBatch();
                    if (i % 100 == 0) {
                        ps.executeBatch();
                        ps.clearBatch();
                    }
                }
                ps.executeBatch();
                conn.commit();
                System.out.println("完成批量插入数据");
            } catch (SQLException e) {
                conn.rollback();
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
